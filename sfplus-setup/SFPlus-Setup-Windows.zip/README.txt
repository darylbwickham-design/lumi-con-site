SATISFACTORY PLUS SETUP
Windows Steam | Satisfactory 1.2.5.0 | CL 517554

1. Extract the whole ZIP, then open SFPlus-Setup.exe.
2. Choose an install folder. Click Copy beside the Steam command, then Install SF+.
3. If Steam opens its Console tab, paste the command there and press Enter.
   Stay signed into the Steam account that owns Satisfactory. Setup continues
   after Steam prints "Depot download complete".
4. Use the Satisfactory Plus desktop shortcut when setup finishes.
   With Factory Live selected, look for Satisfactory Plus - Factory Live.

If you already downloaded CL 517554, use "Use a game copy you already downloaded".
On a single drive, allow about 60 GB for Steam's download and the separate copy.
If interrupted, rerun setup with the same install folder.

Setup installs SF+ 2026.3.489, SML 3.12.0, Infinite Zoop 1.11.2,
RoadMaker 1.4.0, and their pinned libraries. Factory Live 0.9.8 is optional.
The installed copy keeps its saves in UserData. You can copy your existing saves
using the checkbox in Setup.

Setup page
https://lumi-con.com/sfplus-setup/

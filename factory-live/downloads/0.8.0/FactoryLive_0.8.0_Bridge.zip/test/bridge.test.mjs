import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { once } from 'node:events';
import { test } from 'node:test';
import { createBridge, validateConfig } from '../bridge.mjs';
import { connectStreamerBot } from '../streamerbot.mjs';

const config = JSON.parse(await readFile(new URL('../bridge.config.json', import.meta.url), 'utf8'));
const keys = { gameToken: 'a'.repeat(64), webhookToken: 'b'.repeat(64) };
const game = { session: '01234567-4321-4321-4321-0123456789ab', ready: true, free: 4, active: 0, slow: false };
const backpackGame = { ...game, backpack: { ready: true, snapshot: false, recovery: false } };

async function start(t, customConfig = config) {
  const options = validateConfig(structuredClone(customConfig));
  let time = 50_000;
  const { server, trigger } = createBridge(options, keys, () => time);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  options.port = server.address().port;
  t.after(() => {
    server.close();
    server.closeAllConnections();
  });
  async function call(path, data, token = keys.gameToken, method = 'POST') {
    const response = await fetch(`http://127.0.0.1:${options.port}/v1/${path}`, {
      method, headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: data === undefined ? undefined : JSON.stringify(data)
    });
    return [response.status, await response.json()];
  }
  return { call, trigger, advance: ms => { time += ms; } };
}

test('webhooks require their own token and an armed game', async t => {
  const { call } = await start(t);
  const request = { preset: 'cluster-rain', eventId: 'test:1' };
  assert.equal((await call('arm'))[0], 409);
  assert.equal((await call('trigger', request))[0], 401);
  assert.equal((await call('arm', undefined, keys.webhookToken))[0], 401);
  assert.equal((await call('trigger', request, keys.webhookToken))[0], 409);
  await call('game', game);
  assert.equal((await call('arm'))[0], 200);
  assert.equal((await call('trigger', { preset: 'toString' }, keys.webhookToken))[0], 400);
  const [code, receipt] = await call('trigger', request, keys.webhookToken);
  assert.equal(code, 202);
  assert.equal(receipt.count, 5);
  assert.deepEqual(await call('trigger', request, keys.webhookToken), [200, { duplicate: true }]);
  assert.equal((await call('trigger', { ...request, eventId: 'test:2' }, keys.webhookToken))[0], 429);
});

test('random presets queue one available choice and share its cooldown and event deduplication', async t => {
  const { call, trigger } = await start(t);
  await call('game', game);
  assert.deepEqual(trigger('surprise-me'), [409, { error: 'game_not_armed_or_ready' }]);
  await call('arm');
  // This game advertises no Stingers or player actions, leaving two available roulette choices.
  assert.deepEqual(trigger('surprise-me'), [409, { error: 'random_choices_unavailable' }]);
  const [code, receipt] = trigger('creature-roulette', 'roulette:1');
  assert.equal(code, 202);
  assert.ok(['alpha-hogs', 'spitter-pack'].includes(receipt.selectedPreset));
  assert.equal(trigger(receipt.selectedPreset)[1].error, 'cooldown');
  assert.deepEqual(trigger('creature-roulette', 'roulette:1'), [200, { duplicate: true }]);
  assert.deepEqual(trigger('creature-roulette', 'roulette:2'), [429, { error: 'cooldown', retryAfterMs: 60000 }]);
  const [, delivery] = await call('game', game);
  assert.equal(delivery.job.id, receipt.id);
  assert.equal(delivery.job.creature, config.presets[receipt.selectedPreset].creature);
  assert.equal((await call('game', { ...game, ack: receipt.id }))[1].job, undefined);

  const invalid = structuredClone(config);
  for (const choice of ['creature-roulette', 'surprise-me', 'nuke-drop', 'missing']) {
    invalid.presets['creature-roulette'].choices[0] = choice;
    assert.throws(() => validateConfig(invalid), /Invalid random preset/);
  }
});

test('connection check exposes readiness to the webhook token and expires stale sessions', async t => {
  const { call, advance } = await start(t);
  const check = () => call('connection', undefined, keys.webhookToken, 'GET');
  assert.equal((await call('connection', undefined, keys.gameToken, 'GET'))[0], 401);
  assert.equal((await call('status', undefined, keys.webhookToken, 'GET'))[0], 401);
  assert.deepEqual(await check(), [200, { armed: false, connected: false, ready: false, slow: false }]);
  await call('game', game);
  assert.deepEqual(await check(), [200, { armed: false, connected: true, ready: true, slow: false }]);
  await call('arm');
  await call('game', { ...game, slow: true });
  assert.deepEqual(await check(), [200, { armed: true, connected: true, ready: true, slow: true }]);
  advance(3001);
  assert.deepEqual(await check(), [200, { armed: false, connected: false, ready: false, slow: false }]);
});

test('delivers each configured Nobelisk type and accepts the old cluster preset shape', async t => {
  const options = structuredClone(config);
  options.presets['legacy-cluster'] = { effect: 'cluster', count: 2, cooldownSeconds: 6 };
  options.presets['random-teleport'] = { effect: 'teleport', count: 1, cooldownSeconds: 90 };
  const variants = [
    ['nobelisk-rain', 'standard'], ['pulse-rain', 'pulse'], ['gas-rain', 'gas'],
    ['cluster-rain', 'cluster'], ['nuke-drop', 'nuke'], ['legacy-cluster', 'cluster']
  ];
  const { call, trigger, advance } = await start(t, options);
  const current = { ...game, nobeliskTypes: ['standard', 'pulse', 'gas', 'cluster', 'nuke'] };
  await call('game', current);
  await call('arm');
  assert.deepEqual(trigger('random-teleport'), [409, { error: 'effect_disabled' }]);
  for (const [preset, type] of variants) {
    const [code, receipt] = trigger(preset);
    assert.equal(code, 202);
    const [, delivery] = await call('game', current);
    assert.deepEqual(delivery.job, {
      id: receipt.id, effect: 'nobelisk', nobelisk: type, count: options.presets[preset].count
    });
    await call('game', { ...current, ack: receipt.id });
    advance(1000);
  }

  const invalid = structuredClone(options);
  invalid.presets['nuke-drop'].count = 2;
  assert.throws(() => validateConfig(invalid), /Invalid preset/);
  invalid.presets['nuke-drop'].nobelisk = 'other';
  assert.throws(() => validateConfig(invalid), /Invalid preset/);
});

test('Nobelisk variants share queue capacity and nuclear aliases share a cooldown', async t => {
  const options = structuredClone(config);
  options.presets['another-nuke'] = { ...options.presets['nuke-drop'] };
  const { call, trigger } = await start(t, options);
  const current = { ...game, nobeliskTypes: ['standard', 'cluster', 'nuke'],
    pending: { creatures: 0, cluster: 6 } };
  await call('game', current);
  await call('arm');
  assert.deepEqual(trigger('gas-rain'), [409, { error: 'nobelisk_unavailable' }]);
  assert.equal(trigger('nobelisk-rain')[0], 202);
  assert.deepEqual(trigger('cluster-rain'), [429, { error: 'queue_full' }]);
  await call('disarm');
  await call('arm');
  assert.equal(trigger('nuke-drop')[0], 202);
  assert.deepEqual(trigger('another-nuke'), [429, { error: 'cooldown', retryAfterMs: 15000 }]);
  await call('disarm');
  await call('arm');
  assert.deepEqual(trigger('another-nuke'), [429, { error: 'cooldown', retryAfterMs: 15000 }]);
});

test('reports actual Nobelisk impacts separately from launches and expired drops', async t => {
  const { call, trigger } = await start(t);
  const counters = { launched: 8, impacted: 4, expired: 1, cancelled: 1, inFlight: 2 };
  const current = { ...game, pending: { creatures: 0, cluster: 3 },
    nobelisks: counters, nobeliskTypes: ['standard', 'cluster'] };
  assert.equal((await call('game', current))[0], 200);
  const [, status] = await call('status', undefined, keys.gameToken, 'GET');
  assert.deepEqual(status.game.nobelisks, counters);
  assert.deepEqual(status.game.nobeliskTypes, current.nobeliskTypes);
  assert.equal((await call('game', { ...current, nobelisks: { ...counters, impacted: 5 } }))[0], 400);
  assert.equal((await call('game', { ...current, nobeliskTypes: ['cluster', 'cluster'] }))[0], 400);

  await call('game', game);
  await call('arm');
  assert.deepEqual(trigger('nobelisk-rain'), [409, { error: 'nobelisk_unavailable' }]);
  const [code, receipt] = trigger('cluster-rain');
  assert.equal(code, 202);
  assert.deepEqual((await call('game', game))[1].job, { id: receipt.id, effect: 'cluster', count: 5 });
});

test('host inventory commands work disarmed, require operator auth and acknowledge each operation', async t => {
  const { call, trigger } = await start(t);
  await call('game', game);
  assert.deepEqual(await call('inventory', { action: 'snapshot' }), [409, { error: 'backpack_unavailable' }]);
  assert.deepEqual(await call('inventory', { action: 'restore' }, keys.webhookToken), [401, { error: 'unauthorized' }]);
  await call('game', backpackGame);
  assert.equal(trigger('pack-shuffle')[0], 409);
  assert.equal((await call('inventory', { action: 'shuffle' }))[0], 400);

  let current = backpackGame;
  for (const [action, code] of [['snapshot', 'saved'], ['restore', 'restored'], ['undo', 'undone']]) {
    const [accepted, { id }] = await call('inventory', { action });
    assert.equal(accepted, 202);
    const [, delivery] = await call('game', current);
    assert.equal(delivery.armed, false);
    assert.deepEqual(delivery.backpackCommand, { id, action });
    assert.deepEqual((await call('game', current))[1].backpackCommand, { id, action });
    assert.deepEqual(await call(`inventory/result/${id}`, undefined, keys.gameToken, 'GET'), [202, { pending: true }]);
    assert.equal((await call(`inventory/result/${id}`, undefined, keys.webhookToken, 'GET'))[0], 401);
    assert.deepEqual(await call('inventory', { action: 'snapshot' }), [429, { error: 'backpack_busy' }]);
    const last = { id, action, code, stacks: 17 };
    current = { ...current, backpack: { ...current.backpack, snapshot: true, recovery: action !== 'snapshot', last } };
    assert.equal((await call('game', current))[1].backpackCommand, undefined);
    assert.deepEqual(await call(`inventory/result/${id}`, undefined, keys.gameToken, 'GET'), [200, last]);
  }
});

test('shuffle aliases share a cooldown and a viewer cannot substitute a restore action', async t => {
  const options = structuredClone(config);
  options.presets['alternate-shuffle'] = { ...options.presets['pack-shuffle'] };
  const { call, trigger, advance } = await start(t, options);
  await call('game', backpackGame);
  await call('arm');
  const [code, { id }] = await call('trigger', { preset: 'pack-shuffle', action: 'restore' }, keys.webhookToken);
  assert.equal(code, 202);
  const [, response] = await call('game', backpackGame);
  assert.deepEqual(response.backpackCommand, { id, action: 'shuffle' });
  assert.deepEqual(trigger('alternate-shuffle'), [429, { error: 'cooldown', retryAfterMs: 20000 }]);
  await call('disarm');
  assert.equal((await call('game', backpackGame))[1].backpackCommand, undefined);
  const [, interrupted] = await call(`inventory/result/${id}`, undefined, keys.gameToken, 'GET');
  assert.equal(interrupted.code, 'unconfirmed');
  await call('arm');
  assert.equal(trigger('alternate-shuffle')[0], 429);
  advance(3001);
  const newWorld = { ...backpackGame, session: 'dddddddd-eeee-ffff-0000-999999999999' };
  const [, afterReload] = await call('game', newWorld);
  assert.equal(afterReload.armed, false);
  assert.equal(afterReload.backpackCommand, undefined);
  assert.equal(trigger('pack-shuffle')[0], 409);
});

test('slow frames defer backpack delivery and stale commands expire without crossing worlds', async t => {
  const { call, advance } = await start(t);
  await call('game', backpackGame);
  const [, { id }] = await call('inventory', { action: 'restore' });
  const slow = { ...backpackGame, slow: true };
  for (let i = 0; i < 3; i++) {
    advance(2700);
    assert.equal((await call('game', slow))[1].backpackCommand, undefined);
  }
  const [, result] = await call(`inventory/result/${id}`, undefined, keys.gameToken, 'GET');
  assert.equal(result.code, 'expired');
  assert.equal((await call('game', backpackGame))[1].backpackCommand, undefined);
});

test('Stingers require a supported game and Hatcher requests share a two-nest cap', async t => {
  const options = structuredClone(config);
  options.presets['hatcher-alias'] = { ...options.presets['hatcher-drop'] };
  const invalid = structuredClone(options);
  invalid.presets['hatcher-drop'].count = 3;
  assert.throws(() => validateConfig(invalid), /Invalid preset/);
  const { call, trigger } = await start(t, options);
  await call('game', game);
  await call('arm');
  assert.deepEqual(trigger('stinger-pack'), [409, { error: 'creature_unavailable' }]);
  const current = { ...game, active: 1, creatureTypes: ['stinger', 'elite-stinger', 'crab-hatcher'],
    pending: { creatures: 0, cluster: 0 }, hatchers: { alive: 1, pending: 0 } };
  await call('game', current);
  for (const [preset, creature, count] of [['stinger-pack', 'stinger', 12], ['elite-stinger', 'elite-stinger', 1]]) {
    const [code, receipt] = trigger(preset);
    assert.equal(code, 202);
    assert.deepEqual((await call('game', current))[1].job, { id: receipt.id, effect: 'creatures', creature, count });
    await call('game', { ...current, ack: receipt.id });
  }

  const [code, receipt] = trigger('hatcher-drop');
  assert.equal(code, 202);
  assert.deepEqual(trigger('hatcher-alias'), [429, { error: 'hatcher_limit' }]);
  assert.deepEqual((await call('game', current))[1].job,
    { id: receipt.id, effect: 'creatures', creature: 'crab-hatcher', count: 1 });
  assert.deepEqual(trigger('hatcher-alias'), [429, { error: 'hatcher_limit' }]);
  await call('game', { ...current, ack: receipt.id, pending: { creatures: 1, cluster: 0 }, hatchers: { alive: 1, pending: 1 } });
  assert.deepEqual(trigger('hatcher-alias'), [429, { error: 'hatcher_limit' }]);
  assert.equal((await call('game', { ...current, active: 3, hatchers: { alive: 3, pending: 0 } }))[0], 400);
});

test('Turn Around requires the on-foot capability, stays in the viewer lane and shares a cooldown across aliases', async t => {
  const options = structuredClone(config);
  options.presets['another-turn'] = { ...options.presets['turn-around'] };
  const { call, trigger } = await start(t, options);
  await call('game', backpackGame);
  await call('arm');
  assert.deepEqual(trigger('turn-around'), [409, { error: 'turn_unavailable' }]);
  const current = { ...backpackGame, turnReady: true };
  await call('game', current);
  const [code, { id }] = trigger('turn-around');
  assert.equal(code, 202);
  assert.equal((await call('game', { ...current, turnReady: false }))[1].backpackCommand, undefined);
  assert.deepEqual((await call('game', current))[1].backpackCommand, { id, action: 'turn-around' });
  assert.deepEqual(trigger('another-turn'), [429, { error: 'cooldown', retryAfterMs: 20000 }]);
  const last = { id, action: 'turn-around', code: 'turned', stacks: 0 };
  assert.equal((await call('game', { ...current, backpack: { ...current.backpack, last } }))[1].backpackCommand, undefined);
  await call('disarm');
  assert.deepEqual(trigger('another-turn'), [409, { error: 'game_not_armed_or_ready' }]);
});

test('defers during slow frames, retries unacknowledged jobs and reserves a cluster slot', async t => {
  const { call, trigger } = await start(t);
  await call('game', game);
  await call('arm');
  assert.equal(trigger('hog-swarm')[0], 202);
  assert.equal((await call('game', { ...game, slow: true }))[1].job, undefined);
  assert.deepEqual(trigger('cluster-rain'), [429, { error: 'game_throttling' }]);
  assert.equal((await call('game', { ...game, free: 1 }))[1].job, undefined);
  const [, clusterReceipt] = trigger('cluster-rain');
  const [, first] = await call('game', { ...game, free: 1 });
  assert.equal(first.job.id, clusterReceipt.id);
  assert.deepEqual((await call('game', game))[1], first);
  const [, second] = await call('game', { ...game, ack: first.job.id });
  assert.equal(second.job.creature, 'hog');
  assert.equal(second.job.count, 80);
  const [, empty] = await call('game', { ...game, ack: second.job.id });
  assert.equal(empty.job, undefined);
});

test('disarm, competing connections and stale heartbeats clear or protect the queue', async t => {
  const { call, trigger, advance } = await start(t);
  await call('game', game);
  await call('arm');
  trigger('hog-swarm');
  trigger('cluster-rain');
  const [, before] = await call('game', game);
  const rival = { ...game, session: 'aaaaaaaa-bbbb-cccc-dddd-0123456789ab' };
  assert.equal((await call('game', rival))[0], 409);
  await call('disarm');
  const [, after] = await call('game', game);
  assert.equal(after.armed, false);
  assert.notEqual(after.epoch, before.epoch);
  assert.equal(after.job, undefined);
  await call('arm');
  trigger('cluster-rain');
  advance(3_001);
  const [code, replacement] = await call('game', rival);
  assert.equal(code, 200);
  assert.equal(replacement.armed, false);
  assert.equal(replacement.job, undefined);
});

test('limits cover queued, in-flight and game work and reserve room for clusters', async t => {
  const options = structuredClone(config);
  options.presets.first = { effect: 'creatures', creature: 'hog', count: 500, cooldownSeconds: 2 };
  options.presets.second = { ...options.presets.first };
  const { call, trigger } = await start(t, options);
  await call('game', game);
  await call('arm');
  const [response, receipt] = trigger('first');
  assert.equal(response, 202);
  assert.deepEqual(trigger('second'), [429, { error: 'queue_full' }]);
  const [, inFlight] = await call('game', game);
  assert.equal(inFlight.job.id, receipt.id);
  assert.deepEqual(trigger('second'), [429, { error: 'queue_full' }]);

  await call('game', { ...game, ack: receipt.id, pending: { creatures: 500, cluster: 0 } });
  assert.deepEqual(trigger('second'), [429, { error: 'queue_full' }]);
  assert.equal(trigger('cluster-rain')[0], 202);
  await call('game', { ...game, pending: { creatures: 420, cluster: 7 } });
  assert.equal(trigger('hog-swarm')[0], 202);
  assert.deepEqual(trigger('alpha-hogs'), [429, { error: 'queue_full' }]);
  assert.equal((await call('game', { ...game, pending: { creatures: 501, cluster: 0 } }))[0], 400);
});

test('ten thousand distinct mapped chat events cannot fill more than one creature queue', async t => {
  const options = structuredClone(config);
  for (let i = 0; i < 40; i++) {
    options.presets[`swarm-${i}`] = { effect: 'creatures', creature: 'hog', count: 50, cooldownSeconds: 2 };
  }
  const { call, trigger, advance } = await start(t, options);
  await call('game', game);
  await call('arm');

  let accepted = 0;
  for (let i = 0; i < 10_000; i++) {
    const [code] = trigger(`swarm-${i % 40}`, `chat:${i}`);
    if (code === 202) accepted++;
    else assert.equal(code, 429);
  }
  assert.equal(accepted, 4);
  assert.equal(trigger('cluster-rain')[0], 202);
  advance(1000);
  assert.equal(trigger('swarm-10', 'chat:after-refill')[0], 202);
  assert.equal(trigger('swarm-11', 'chat:over-refill')[0], 429);
});

test('HTTP spam hits the webhook limiter while game heartbeat and disarm still respond', async t => {
  const { call } = await start(t);
  await call('game', game);
  await call('arm');
  for (let i = 0; i < 16; i++) {
    await call('trigger', { preset: 'hog-swarm', eventId: `hook:${i}` }, keys.webhookToken);
  }
  const [heartbeat, rejected, stopped] = await Promise.all([
    call('game', game),
    call('trigger', { preset: 'hog-swarm' }, keys.webhookToken),
    call('disarm')
  ]);
  assert.equal(heartbeat[0], 200);
  assert.deepEqual(rejected, [429, { error: 'webhook_rate_limit' }]);
  assert.equal(stopped[1].armed, false);
});

test('reports the loaded save’s mob ledger through disarm and a world reload', async t => {
  const { call, advance } = await start(t);
  const status = () => call('status', undefined, keys.gameToken, 'GET');
  const mobs = { spawned: 30, killed: 7, missing: 2 };
  assert.equal((await call('game', { ...game, active: 21, mobs }))[0], 200);
  assert.deepEqual((await status())[1].game.mobs, { ...mobs, alive: 21 });

  await call('arm');
  await call('disarm');
  assert.deepEqual((await status())[1].game.mobs, { ...mobs, alive: 21 });

  advance(3001);
  const reopened = { ...game, session: 'aaaaaaaa-bbbb-cccc-dddd-0123456789ab' };
  await call('game', { ...reopened, active: 21, mobs });
  assert.deepEqual((await status())[1].game.mobs, { ...mobs, alive: 21 });
  assert.equal((await status())[1].armed, false);
  assert.equal((await call('game', { ...reopened, active: 22, mobs }))[0], 400);

  advance(3001);
  await call('game', { ...game, mobs: { spawned: 0, killed: 0, missing: 0 } });
  assert.deepEqual((await status())[1].game.mobs, { spawned: 0, alive: 0, killed: 0, missing: 0 });
});

test('Streamer.bot authenticates, subscribes and maps configured commands and reward IDs', () => {
  class FakeSocket extends EventTarget {
    sent = [];
    send(packet) { this.sent.push(JSON.parse(packet)); }
    receive(packet) { this.dispatchEvent(new MessageEvent('message', { data: JSON.stringify(packet) })); }
    close() { this.dispatchEvent(new Event('close')); }
  }
  const socket = new FakeSocket();
  const triggers = [];
  const stop = connectStreamerBot({
    url: 'ws://127.0.0.1:8080/',
    commands: { '!hogs': 'hog-swarm' },
    rewards: { 'test-reward': 'cluster-rain' }
  }, (...args) => triggers.push(args), 'test-password', () => socket);

  try {
    socket.receive({ request: 'Hello', authentication: { salt: 'salt', challenge: 'challenge' } });
    assert.equal(socket.sent[0].request, 'Authenticate');
    assert.match(socket.sent[0].authentication, /^[A-Za-z0-9+/]{43}=$/);
    socket.receive({ id: 'factorylive-auth', status: 'ok' });
    assert.deepEqual(socket.sent[1].events, { Command: ['Triggered'], Twitch: ['RewardRedemption'] });
    socket.receive({ id: 'factorylive-subscribe', status: 'ok' });
    socket.receive({
      timeStamp: 'now', event: { source: 'Command', type: 'Triggered' },
      data: { command: '!HOGS', user: { id: 'viewer' } }
    });
    socket.receive({
      event: { source: 'Twitch', type: 'RewardRedemption' },
      data: { reward: { id: 'test-reward' }, redemptionId: 'r1' }
    });
    socket.receive({
      event: { source: 'Twitch', type: 'RewardRedemption' },
      data: { reward: { id: 'test-reward' }, redemptionId: 'r2', isFromSharedChatGuest: true }
    });
    assert.deepEqual(triggers, [['hog-swarm', 'sb:command:!hogs:now:viewer'], ['cluster-rain', 'sb:reward:r1']]);
  } finally {
    stop();
  }
});

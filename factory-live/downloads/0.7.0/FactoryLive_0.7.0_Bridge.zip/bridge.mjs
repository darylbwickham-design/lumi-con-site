import { randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { createServer } from 'node:http';
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setTimeout as delay } from 'node:timers/promises';
import { connectStreamerBot } from './streamerbot.mjs';

const root = fileURLToPath(new URL('.', import.meta.url));
const stateDir = process.env.FACTORYLIVE_HOME || (process.env.LOCALAPPDATA
  ? join(process.env.LOCALAPPDATA, 'FactoryLive')
  : join(root, 'Saved'));
const bodyLimit = 4096;
const heartbeatMs = 3000;
const queueLifeMs = 120_000;
const legacyCreatures = ['hog', 'alpha-hog', 'spitter'];
const creatures = new Set([...legacyCreatures, 'stinger', 'elite-stinger', 'crab-hatcher']);
const nobeliskTypes = new Set(['standard', 'gas', 'pulse', 'cluster', 'nuke']);
const nukeIntervalMs = 15_000;
const viewerActionIntervalMs = 20_000;
const viewerActions = new Map([['backpack-shuffle', 'shuffle'], ['turn-around', 'turn-around']]);
const maxHatchers = 2;
const backpackQueueMs = 8_000;
const operatorBackpackActions = new Set(['snapshot', 'restore', 'undo']);
const backpackSuccess = new Set(['saved', 'restored', 'undone', 'shuffled', 'turned']);
const jobIdPattern = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const tokenPattern = /^[a-f0-9]{64}$/;
const limits = {
  creatures: { units: 500, jobs: 8, burst: 4 },
  nobelisk: { units: 12, jobs: 4, burst: 2 }
};

function validTypes(types, allowed) {
  return Array.isArray(types) && types.length <= allowed.size &&
    new Set(types).size === types.length && types.every(type => allowed.has(type));
}

function tokenBucket(capacity, perSecond, now) {
  let tokens = capacity;
  let last = now();
  return () => {
    const t = now();
    tokens = Math.min(capacity, tokens + Math.max(0, t - last) * perSecond / 1000);
    last = t;
    if (tokens < 1) return false;
    tokens -= 1;
    return true;
  };
}

export function validateConfig(config) {
  if (!Number.isInteger(config.port) || config.port < 1024 || config.port > 65535) {
    throw new Error('port must be an integer from 1024 to 65535');
  }
  if (!config.presets || typeof config.presets !== 'object' || Array.isArray(config.presets)) {
    throw new Error('presets must be an object');
  }
  for (const [name, p] of Object.entries(config.presets)) {
    if (!/^[a-z0-9-]{1,40}$/.test(name)) throw new Error(`Invalid preset "${name}"`);
    // Let an existing config load with its old mappings after removing teleport from the mod.
    if (p?.effect === 'teleport') continue;
    const isCreature = p?.effect === 'creatures' && creatures.has(p.creature);
    const type = p?.effect === 'cluster' ? 'cluster' : p?.nobelisk;
    const isNobelisk = p?.effect === 'cluster' || (p?.effect === 'nobelisk' && nobeliskTypes.has(type));
    const isPlayerAction = viewerActions.has(p?.effect);
    const maxCount = isCreature ? (p.creature === 'crab-hatcher' ? maxHatchers : limits.creatures.units)
      : (type === 'nuke' || isPlayerAction ? 1 : limits.nobelisk.units);
    const minCooldown = isPlayerAction ? viewerActionIntervalMs / 1000 : 2;
    if ((!isCreature && !isNobelisk && !isPlayerAction) || !Number.isInteger(p.count) || p.count < 1 || p.count > maxCount ||
        !Number.isInteger(p.cooldownSeconds) || p.cooldownSeconds < minCooldown || p.cooldownSeconds > 600) {
      throw new Error(`Invalid preset "${name}"`);
    }
  }
  const bot = config.streamerBot;
  if (bot?.enabled) {
    const url = new URL(bot.url);
    if (url.protocol !== 'ws:' || url.hostname !== '127.0.0.1' || url.username || url.password || url.hash) {
      throw new Error('streamerBot.url must be a loopback ws://127.0.0.1 address');
    }
    for (const group of [bot.commands, bot.rewards]) {
      if (!group || typeof group !== 'object' || Array.isArray(group)) {
        throw new Error('streamerBot commands and rewards must be objects');
      }
      for (const [key, preset] of Object.entries(group)) {
        if (!key || !Object.hasOwn(config.presets, preset)) {
          throw new Error(`Invalid Streamer.bot mapping "${key}"`);
        }
      }
    }
  }
  return config;
}

export function createBridge(config, keys, now = () => performance.now()) {
  let session = null;
  let lastSeen = 0;
  let details = {};
  let armed = false;
  let epoch = randomUUID();
  let queue = [];
  let delivery = null;
  let lastNuke = -Infinity;
  const lastViewerAction = new Map();
  let pendingBackpack = null;
  const backpackResults = new Map();
  let webhookReaders = 0;
  const admitWebhook = tokenBucket(16, 12, now);
  const admitEvent = {
    creatures: tokenBucket(limits.creatures.burst, 1, now),
    nobelisk: tokenBucket(limits.nobelisk.burst, 1, now)
  };
  const lastUsed = new Map();
  const seen = new Map();
  const gameAuth = Buffer.from(`Bearer ${keys.gameToken}`);
  const webhookAuth = Buffer.from(`Bearer ${keys.webhookToken}`);

  function finishBackpack(code, stacks = 0) {
    const { id, action } = pendingBackpack;
    backpackResults.set(id, { id, action, code, stacks });
    if (backpackResults.size > 16) backpackResults.delete(backpackResults.keys().next().value);
    pendingBackpack = null;
  }

  function queueBackpack(action) {
    if (!session) return [409, { error: 'game_not_ready' }];
    if (action === 'turn-around' ? !details.turnReady : !details.backpack?.ready) {
      return [409, { error: action === 'turn-around' ? 'turn_unavailable' : 'backpack_unavailable' }];
    }
    if (details.slow) return [429, { error: 'game_throttling' }];
    if (pendingBackpack) return [429, { error: 'backpack_busy' }];
    pendingBackpack = { id: randomUUID(), action, expires: now() + backpackQueueMs, delivered: false };
    return [202, { accepted: true, id: pendingBackpack.id, count: 1 }];
  }

  function stop() {
    armed = false;
    epoch = randomUUID();
    queue = [];
    delivery = null;
    if (pendingBackpack) finishBackpack(pendingBackpack.delivered ? 'unconfirmed' : 'cancelled');
    lastUsed.clear();
  }

  function expire() {
    const t = now();
    if (session && t - lastSeen > heartbeatMs) {
      stop();
      session = null;
      details = {};
    }
    if (queue.some(job => job.expires <= t)) queue = queue.filter(job => job.expires > t);
    if (delivery && delivery.expires <= t) delivery = null;
    if (pendingBackpack && pendingBackpack.expires <= t) {
      finishBackpack(pendingBackpack.delivered ? 'unconfirmed' : 'expired');
    }
    for (const [id, expires] of seen) {
      if (expires > t) break;
      seen.delete(id);
    }
  }

  function recordPreset(preset, eventId, time) {
    lastUsed.set(preset, time);
    if (eventId) {
      seen.set(eventId, time + 600_000);
      if (seen.size > 4096) seen.delete(seen.keys().next().value);
    }
  }

  function trigger(preset, eventId) {
    expire();
    if (typeof preset !== 'string' || !Object.hasOwn(config.presets, preset)) {
      return [400, { error: 'unknown_preset' }];
    }
    if (eventId !== undefined && (typeof eventId !== 'string' || !eventId || eventId.length > 200)) {
      return [400, { error: 'invalid_event_id' }];
    }
    const p = config.presets[preset];
    if (p.effect === 'teleport') return [409, { error: 'effect_disabled' }];
    if (seen.has(eventId)) return [200, { duplicate: true }];
    if (!armed || !details.ready) return [409, { error: 'game_not_armed_or_ready' }];
    if (details.slow) return [429, { error: 'game_throttling' }];
    const t = now();
    const effect = p.effect === 'cluster' ? 'nobelisk' : p.effect;
    const type = p.effect === 'cluster' ? 'cluster' : p.nobelisk;
    const waitMs = p.cooldownSeconds * 1000 - (t - (lastUsed.get(preset) ?? -Infinity));
    const viewerAction = viewerActions.get(effect);
    if (viewerAction) {
      const last = lastViewerAction.get(viewerAction) ?? -Infinity;
      const retryAfterMs = Math.max(waitMs, viewerActionIntervalMs - (t - last));
      if (retryAfterMs > 0) return [429, { error: 'cooldown', retryAfterMs }];
      const result = queueBackpack(viewerAction);
      if (result[0] === 202) {
        lastViewerAction.set(viewerAction, t);
        recordPreset(preset, eventId, t);
      }
      return result;
    }
    if (effect === 'creatures' && !(details.creatureTypes ?? legacyCreatures).includes(p.creature)) {
      return [409, { error: 'creature_unavailable' }];
    }
    if (effect === 'nobelisk' && !(details.nobeliskTypes ?? ['cluster']).includes(type)) {
      return [409, { error: 'nobelisk_unavailable' }];
    }
    if (type === 'nuke') {
      const retryAfterMs = nukeIntervalMs - (t - lastNuke);
      if (retryAfterMs > 0) return [429, { error: 'cooldown', retryAfterMs }];
    }
    if (waitMs > 0) return [429, { error: 'cooldown', retryAfterMs: waitMs }];
    const lane = limits[effect];
    const waiting = queue.filter(job => job.effect === effect);
    const delivering = delivery?.effect === effect;
    if (effect === 'creatures' && p.creature === 'crab-hatcher') {
      if (!details.hatchers) return [409, { error: 'creature_unavailable' }];
      const inTransit = delivery?.creature === 'crab-hatcher' ? delivery.count : 0;
      const waitingHatchers = waiting.reduce((total, job) => total + (job.creature === 'crab-hatcher' ? job.count : 0), 0);
      if (details.hatchers.alive + details.hatchers.pending + inTransit + waitingHatchers + p.count > maxHatchers) {
        return [429, { error: 'hatcher_limit' }];
      }
    }
    const queuedUnits = waiting.reduce((total, job) => total + job.count, delivering ? delivery.count : 0);
    const gameUnits = (effect === 'nobelisk' ? details.pending?.cluster : details.pending?.creatures) ?? 0;
    if (waiting.length + Number(delivering) >= lane.jobs || gameUnits + queuedUnits + p.count > lane.units) {
      return [429, { error: 'queue_full' }];
    }
    if (!admitEvent[effect]()) return [429, { error: 'event_rate_limit' }];
    const job = {
      id: randomUUID(), effect, count: p.count, expires: t + queueLifeMs,
      ...(effect === 'creatures' ? { creature: p.creature } : { nobelisk: type })
    };
    queue.push(job);
    recordPreset(preset, eventId, t);
    if (type === 'nuke') lastNuke = t;
    return [202, { accepted: true, id: job.id, count: job.count }];
  }

  function sync(data) {
    if (typeof data.session !== 'string' || !/^[a-f0-9-]{36}$/i.test(data.session) ||
        typeof data.ready !== 'boolean' || !Number.isInteger(data.free) || data.free < 0 || data.free > 4 ||
        !Number.isInteger(data.active) || data.active < 0 || data.active > 32 || typeof data.slow !== 'boolean' ||
        (data.turnReady !== undefined && typeof data.turnReady !== 'boolean')) {
      return [400, { error: 'invalid_game_status' }];
    }
    let mobs;
    if (data.mobs !== undefined) {
      if (!data.mobs || typeof data.mobs !== 'object' || Array.isArray(data.mobs)) {
        return [400, { error: 'invalid_mob_counts' }];
      }
      const { spawned, killed, missing } = data.mobs;
      if (![spawned, killed, missing].every(count => Number.isSafeInteger(count) && count >= 0) ||
          spawned - killed - missing !== data.active) {
        return [400, { error: 'invalid_mob_counts' }];
      }
      mobs = { spawned, alive: data.active, killed, missing };
    }
    let pending;
    if (data.pending !== undefined) {
      const { creatures: creatureCount, cluster } = data.pending ?? {};
      if (!Number.isInteger(creatureCount) || creatureCount < 0 || creatureCount > limits.creatures.units ||
          !Number.isInteger(cluster) || cluster < 0 || cluster > limits.nobelisk.units) {
        return [400, { error: 'invalid_pending_counts' }];
      }
      pending = { creatures: creatureCount, cluster };
    }
    const types = data.nobeliskTypes;
    if (types !== undefined && !validTypes(types, nobeliskTypes)) {
      return [400, { error: 'invalid_nobelisk_types' }];
    }
    if (data.creatureTypes !== undefined && !validTypes(data.creatureTypes, creatures)) {
      return [400, { error: 'invalid_creature_types' }];
    }
    let drops;
    if (data.nobelisks !== undefined) {
      const { launched, impacted, expired, cancelled, inFlight } = data.nobelisks ?? {};
      if (![launched, impacted, expired, cancelled, inFlight].every(count => Number.isSafeInteger(count) && count >= 0) ||
          inFlight > 3 || launched - impacted - expired - cancelled !== inFlight ||
          (pending && inFlight > pending.cluster)) {
        return [400, { error: 'invalid_nobelisk_counts' }];
      }
      drops = { launched, impacted, expired, cancelled, inFlight };
    }
    let hatchers;
    if (data.hatchers !== undefined) {
      const { alive, pending: nestsPending } = data.hatchers ?? {};
      if (![alive, nestsPending].every(value => Number.isInteger(value) && value >= 0) ||
          alive + nestsPending > maxHatchers || alive > data.active || (pending && nestsPending > pending.creatures)) {
        return [400, { error: 'invalid_hatcher_counts' }];
      }
      hatchers = { alive, pending: nestsPending };
    }
    let backpack;
    if (data.backpack !== undefined) {
      const { ready, snapshot, recovery, last } = data.backpack ?? {};
      if (![ready, snapshot, recovery].every(value => typeof value === 'boolean')) {
        return [400, { error: 'invalid_backpack_status' }];
      }
      backpack = { ready, snapshot, recovery };
      if (last !== undefined) {
        const { id, action, code, stacks } = last ?? {};
        if (typeof id !== 'string' || !jobIdPattern.test(id) ||
            (!operatorBackpackActions.has(action) && action !== 'shuffle' && action !== 'turn-around') ||
            typeof code !== 'string' || !/^[a-z_]{1,40}$/.test(code) ||
            !Number.isInteger(stacks) || stacks < 0 || stacks > 512) {
          return [400, { error: 'invalid_backpack_result' }];
        }
        backpack.last = { id, action, code, stacks };
      }
    }
    if (data.session !== session) {
      // A second game instance cannot take over while the first is connected.
      if (session) return [409, { error: 'session_in_use' }];
      session = data.session;
    }
    lastSeen = now();
    details = { ready: data.ready, free: data.free, active: data.active, slow: data.slow };
    if (mobs) details.mobs = mobs;
    if (pending) details.pending = pending;
    if (data.creatureTypes !== undefined) details.creatureTypes = data.creatureTypes;
    if (types !== undefined) details.nobeliskTypes = types;
    if (drops) details.nobelisks = drops;
    if (hatchers) details.hatchers = hatchers;
    if (data.turnReady !== undefined) details.turnReady = data.turnReady;
    if (backpack) {
      details.backpack = backpack;
      const last = backpack.last;
      if (pendingBackpack && last?.id === pendingBackpack.id && last.action === pendingBackpack.action) {
        finishBackpack(last.code, last.stacks);
      } else if (last && backpackResults.get(last.id)?.code === 'unconfirmed') {
        const prior = backpackResults.get(last.id);
        if (prior.action === last.action) backpackResults.set(last.id, last);
      }
    }
    if (delivery && delivery.id === data.ack) delivery = null;
    if (data.ready) {
      const available = job => job.effect === 'nobelisk'
        ? (types ?? ['cluster']).includes(job.nobelisk)
        : (data.creatureTypes ?? legacyCreatures).includes(job.creature);
      if (delivery && !available(delivery)) delivery = null;
      if (queue.length) queue = queue.filter(available);
    }
    if (armed && data.ready && !data.slow && !delivery && data.free > 0 && queue.length) {
      // Keep one game slot free for a Nobelisk event during long creature waves.
      let index = queue.findIndex(job => job.effect === 'nobelisk');
      if (index < 0 && data.free > 1) index = queue.findIndex(job => job.effect === 'creatures');
      if (index >= 0) [delivery] = queue.splice(index, 1);
    }
    const response = { epoch, armed };
    if (pendingBackpack && !data.slow && (armed || operatorBackpackActions.has(pendingBackpack.action)) &&
        (pendingBackpack.action === 'turn-around' ? data.turnReady : backpack?.ready)) {
      const { id, action } = pendingBackpack;
      response.backpackCommand = { id, action };
      pendingBackpack.delivered = true;
    }
    if (armed && data.ready && !data.slow && delivery) {
      const { expires, ...job } = delivery;
      if (types === undefined && job.effect === 'nobelisk') {
        job.effect = 'cluster';
        delete job.nobelisk;
      }
      response.job = job;
    }
    return [200, response];
  }

  function status() {
    return { armed, connected: session !== null, game: details, queued: queue.length, delivering: !!delivery,
      ...(pendingBackpack ? { backpackPending: pendingBackpack.action } : {}) };
  }

  const server = createServer({
    requestTimeout: 5000, headersTimeout: 3000, connectionsCheckingInterval: 1000,
    keepAliveTimeout: 1000, maxHeaderSize: 8192
  },
    async (req, res) => {
      const send = (code, value, close = false) => {
        if (res.destroyed) return;
        const headers = { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' };
        if (close) headers.Connection = 'close';
        res.writeHead(code, headers);
        res.end(JSON.stringify(value));
      };
      if (req.headers.host !== `127.0.0.1:${config.port}`) return send(421, { error: 'invalid_host' });
      const path = req.url;
      const auth = Buffer.from(req.headers.authorization ?? '');
      const expected = path === '/v1/trigger' ? webhookAuth : gameAuth;
      if (auth.length !== expected.length || !timingSafeEqual(auth, expected)) {
        return send(401, { error: 'unauthorized' }, true);
      }
      const webhook = path === '/v1/trigger' && req.method === 'POST';
      if (webhook && (webhookReaders >= 4 || !admitWebhook())) {
        return send(429, { error: 'webhook_rate_limit' }, true);
      }
      if (webhook) webhookReaders++;
      try {
        if (!webhook) expire();
        if (req.method === 'GET' && path === '/v1/status') return send(200, status());
        if (req.method === 'GET' && path.startsWith('/v1/inventory/result/')) {
          const id = path.slice('/v1/inventory/result/'.length);
          if (!jobIdPattern.test(id)) return send(400, { error: 'invalid_command_id' });
          if (pendingBackpack?.id === id) return send(202, { pending: true });
          const result = backpackResults.get(id);
          return result ? send(200, result) : send(404, { error: 'unknown_command' });
        }
        if (req.method !== 'POST') return send(404, { error: 'unknown_route' });
        if (path === '/v1/disarm') {
          stop();
          return send(200, status());
        }
        if (path === '/v1/arm') {
          if (!session || !details.ready) return send(409, { error: 'game_not_ready' });
          armed = true;
          return send(200, status());
        }
        if (!['/v1/trigger', '/v1/game', '/v1/inventory'].includes(path)) return send(404, { error: 'unknown_route' });
        if (!/^application\/json(?:\s*;|$)/i.test(req.headers['content-type'] ?? '')) {
          return send(415, { error: 'expected_json' });
        }
        const data = await readBody(req);
        if (path === '/v1/game') {
          expire();
          return send(...sync(data));
        }
        if (path === '/v1/inventory') {
          if (!operatorBackpackActions.has(data.action)) return send(400, { error: 'invalid_inventory_action' });
          return send(...queueBackpack(data.action));
        }
        return send(...trigger(data.preset, data.eventId));
      } catch (error) {
        return send(error.status ?? 400, { error: error.message }, true);
      } finally {
        if (webhook) webhookReaders--;
      }
    });
  server.maxConnections = 32;
  server.setTimeout(5000, socket => socket.destroy());
  return { server, trigger };
}

async function runBackpackCommand(endpoint, token, action) {
  if (!operatorBackpackActions.has(action) && action !== 'status') {
    throw new Error('Usage: node bridge.mjs inventory snapshot|restore|undo|status');
  }
  const headers = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' };
  if (action === 'status') {
    const response = await fetch(`${endpoint}/status`, { headers, signal: AbortSignal.timeout(3000) });
    const state = await response.json();
    console.log(JSON.stringify(response.ok ? { connected: state.connected, ...state.game.backpack,
      ...(state.backpackPending ? { pending: state.backpackPending } : {}) } : state));
    if (!response.ok) process.exitCode = 1;
    return;
  }
  const response = await fetch(`${endpoint}/inventory`, {
    method: 'POST', headers, body: JSON.stringify({ action }), signal: AbortSignal.timeout(3000)
  });
  const receipt = await response.json();
  if (response.status !== 202) {
    console.log(JSON.stringify(receipt));
    process.exitCode = 1;
    return;
  }
  const deadline = performance.now() + backpackQueueMs + 1000;
  while (performance.now() < deadline) {
    await delay(250);
    const result = await fetch(`${endpoint}/inventory/result/${receipt.id}`, {
      headers, signal: AbortSignal.timeout(2500)
    });
    if (result.status === 202) continue;
    const outcome = await result.json();
    console.log(JSON.stringify(outcome));
    if (!result.ok || !backpackSuccess.has(outcome.code)) process.exitCode = 1;
    return;
  }
  console.log(JSON.stringify({ id: receipt.id, action, code: 'unconfirmed' }));
  process.exitCode = 1;
}

function readBody(req) {
  return new Promise((resolveBody, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size <= bodyLimit) chunks.push(chunk);
      else reject(Object.assign(new Error('body_too_large'), { status: 413 }));
    });
    req.on('error', reject);
    req.on('end', () => {
      try {
        const value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
        if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error();
        resolveBody(value);
      } catch {
        reject(new Error('invalid_json_object'));
      }
    });
  });
}

async function main() {
  const path = join(stateDir, 'link.json');
  const action = process.argv[2] ?? 'serve';
  if (action === 'serve') {
    const configPath = process.argv[3] ?? join(root, 'bridge.config.json');
    const config = validateConfig(JSON.parse(await readFile(configPath, 'utf8')));
    await mkdir(stateDir, { recursive: true });
    let keys;
    try {
      keys = JSON.parse(await readFile(path, 'utf8'));
      if (!tokenPattern.test(keys.gameToken) || !tokenPattern.test(keys.webhookToken) ||
          keys.gameToken === keys.webhookToken) throw new Error(`Invalid tokens in ${path}`);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      keys = { gameToken: randomBytes(32).toString('hex'), webhookToken: randomBytes(32).toString('hex') };
    }
    const bridge = createBridge(config, keys);
    await new Promise((ready, reject) => {
      bridge.server.once('error', reject);
      bridge.server.listen(config.port, '127.0.0.1', ready);
    });
    const temp = `${path}.${randomUUID()}.tmp`;
    await writeFile(temp, JSON.stringify({ port: config.port, ...keys }), { mode: 0o600 });
    await rename(temp, path);
    console.log(`Factory Live listening on http://127.0.0.1:${config.port} (disarmed)`);
    console.log(`Link file: ${path}`);
    const closeBot = config.streamerBot?.enabled
      ? connectStreamerBot(config.streamerBot, bridge.trigger, process.env.FACTORYLIVE_STREAMERBOT_PASSWORD)
      : () => {};
    const stop = () => {
      closeBot();
      bridge.server.close();
    };
    process.once('SIGINT', stop);
    process.once('SIGTERM', stop);
    return;
  }
  if (!['status', 'arm', 'disarm', 'trigger', 'inventory'].includes(action)) {
    throw new Error('Usage: node bridge.mjs [serve [config] | status | arm | disarm | trigger <preset> | inventory <action>]');
  }
  const keys = JSON.parse(await readFile(path, 'utf8'));
  if (!Number.isInteger(keys.port) || keys.port < 1024 || keys.port > 65535 ||
      !tokenPattern.test(keys.gameToken) || !tokenPattern.test(keys.webhookToken)) {
    throw new Error(`Invalid link file at ${path}`);
  }
  const endpoint = `http://127.0.0.1:${keys.port}/v1`;
  if (action === 'inventory') return runBackpackCommand(endpoint, keys.gameToken, process.argv[3]);
  const options = {
    method: action === 'status' ? 'GET' : 'POST',
    headers: { Authorization: `Bearer ${action === 'trigger' ? keys.webhookToken : keys.gameToken}` },
    signal: AbortSignal.timeout(3000)
  };
  if (action === 'trigger') {
    options.headers['Content-Type'] = 'application/json';
    options.body = JSON.stringify({ preset: process.argv[3] });
  }
  const response = await fetch(`${endpoint}/${action}`, options);
  console.log(await response.text());
  if (!response.ok) process.exitCode = 1;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => {
    console.error(error.message);
    process.exit(1);
  });
}
